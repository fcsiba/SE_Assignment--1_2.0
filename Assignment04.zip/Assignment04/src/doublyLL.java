/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp 22962
 */
public class doublyLL {
    node1 head;
    node1 tail;

    public void insert(String d,String m){

        node1 N = new node1(d,m);

        if (head == null) {
            head = N;
            tail = N;
        } else {
            N.prev = tail;
            tail.next = N;
            tail = N;
        }
    }

    public node1 Find(String v) {
        node1 temp = head;
        while (temp.next != null && temp.word!=v) {
            temp = temp.next;
        }
        if (temp.word==v) {
            return temp;
        } else {
            return null;
        }
    }

    public void delete(String v) {
        node1 temp = Find(v);
        if (temp == null) {
            System.out.println("data not found");
        } else if (temp == head) {
            head = head.next;
            head.prev = null;
        } else {
            temp.prev.next = temp.next;
        }

}
    public String toString(){
        String str = "";
        node1 var = head;
        while (var!= null) {
            str = str + var.word+ ", "+var.meaning;
            var = var.next;
        }
        return str;
    }
}
