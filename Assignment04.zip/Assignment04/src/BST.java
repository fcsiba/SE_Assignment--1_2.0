/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp 22962
 */
public class BST {
    static Nodee root;
    public void insert(int d){
        Nodee n = new Nodee(d);
        if(root ==null){
            root = n;
            return;
        }
          Nodee temp = root;
            Nodee prev = null;
            while(temp!=null){
                if(n.data>temp.data){
                    prev = temp;
                    temp = temp.right;
                    
                }
                else if(n.data<temp.data){
                    prev = temp;
                    temp = temp.left;
                }
            }
            if(n.data<prev.data){
                prev.left = n;
            }
            else{
                prev.right = n;
            }
        }
    
        
    
    //public void printInrange(Nodee r, int k1, int k2){
        public static void printRange(Nodee root, int k1, int k2) {
		if (root == null)
			return;
		if (root.data >= k1 && root.data <= k2)
			System.out.printf("%d ", root.data);
		if (root.data > k1)
			printRange(root.left, k1, k2);
		if (root.data < k2)
			printRange(root.right, k1, k2);
	}
    
    
    public boolean find(int t){
        Nodee temp = root;
        Nodee prev = null;
        while(temp!=null&& temp.data!=t ){
            if(t>temp.data){
                    prev = temp;
                    temp = temp.right;
                    
                }
                else if(t<temp.data){
                    prev = temp;
                    temp = temp.left;
                    
                }
        }
        if(temp!=null && t== temp.data){
            return true;
        }
        else 
            return false;
    }
    public void inorder(){
        InOrder(root);
    }
    public void InOrder(Nodee n){
        if(n==null){
            return;
        }
        InOrder(n.left);
        System.out.println(n.data);
        InOrder(n.right);
    }
    public static void main(String[] args) {
        
        BST s = new BST();
        //s.//root= new Nodee()
       s.insert(9);
        s.insert(8);
        s.insert(10);
        s.insert(13);
        s.insert(40);
      s.printRange(root, 10, 40);
     
//s.printInrange(root, 8, 40);
        //s.inorder();

    }

}

