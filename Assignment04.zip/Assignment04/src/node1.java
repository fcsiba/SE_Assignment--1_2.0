/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp 22962
 */
public class node1 {
        node1 prev;
    node1 next;
    String word;
    String meaning;

    node1(String word,String meaning) {
        this.meaning=meaning;
        this.word= word;
    }

    public void getData() {
        System.out.println(word);
    }
     @Override
    public String toString() {
        String string = "word: " + this.word + " meaning: " + this.meaning + "\n";
        return string;
    }
}
   




