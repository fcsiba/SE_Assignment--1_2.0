/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp 22962
 */
public class node2 {
    String word;
    String meaning;
    node2 left;
    node2 right;

    public node2(String word, String meaning) {
        this.word = word;
        this.meaning = meaning;
    }

    @Override
    public String toString() {
        String string = "word: " + this.word + " meaning: " + this.meaning + "\n";
        return string;
    }

}
