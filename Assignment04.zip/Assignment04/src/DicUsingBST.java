/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

/**
 *
 * @author hp 22962
 */
public class DicUsingBST {
      public static void main(String[] args) throws IOException {
        DictBST d = new DictBST();
        DictBST D = new DictBST();
        FileInputStream fstream = new FileInputStream("C:\\Users\\hp\\Documents\\NetBeansProjects\\Assignment04\\src//Dictionary.csv");
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));

        ArrayList<Nodee> arr = new ArrayList<Nodee>();
        String strLine;
        String print = "";
        while ((strLine = br.readLine()) != null) {
            String word;
            String meaning = "";
            String[] array = strLine.split("  ");
            if (array.length != 0) {
                word = array[0];
            } else {
                word = "";
            }
            for (int i = 1; i < array.length; i++) {
                meaning = meaning + array[i] + " ";
            }
            if (!word.equals("") && !meaning.equals("")) {
                arr.add(new node2(word, meaning));
                D.insert(word, meaning);
            }
        }
        in.close();
        D.display();
        System.out.println(D.find("Calisthenics"));
        System.out.println(D.delete("mOnEy OrdeR"));
        System.out.println(D.find("money order"));
        System.out.println("Height of unbalanced Tree: " + D.max);
       }

}
