
import java.util.ArrayList;
import java.util.Stack;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp 22962
 */
public class DictBST {
    node2 root;
    int maxL = 0;
    int maxR = 0;
    int max = 0;

    Nodee sortedArrayToBST(ArrayList<node2> arr, int start, int end) {

        if (start > end) {
            return null;
        }

        int mid = (start + end) / 2;
        node2 n = new node2(arr.get(mid).word, arr.get(mid).meaning);

        n.left = sortedArrayToBST(arr, start, mid - 1);

        n.right = sortedArrayToBST(arr, mid + 1, end);

        return n;
    }

    public int height() {
        int sum = 0;
        node2 temp = root;
        while (temp != null) {
            sum++;
            temp = temp.right;
        }
        return sum;
    }

    public void insert(String word, String meaning) {
        node2 n = new node2(word, meaning);
        if (root == null) {
            root = n;
        } else {
            int tempMax = 0;
            node2 temp = root;
            node2 p = root;
            int tempSum = 0;
            int wordSum = strToAsc(word.toLowerCase());
            while (temp != null) {
                tempSum = strToAsc(temp.word.toLowerCase());
                if (wordSum < tempSum) {
                    p = temp;
                    temp = temp.left;
                    tempMax++;
                } else {
                    p = temp;
                    temp = temp.right;
                    tempMax++;
                }
            }
            if (wordSum < tempSum) {
                p.left = n;
                tempMax++;
            } else {
                p.right = n;
                tempMax++;
            }
            if (tempMax > max) {
                max = tempMax;
            }
        }
    }

    private int strToAsc(String x) {
        int sum = 0;
        for (int i = 0; i < x.length(); i++) {
            sum = sum + (int) x.charAt(i);
        }
        return sum;
    }

    public String find(String word) {
        String str = "";
        boolean found = false;
        if (root == null) {
            System.out.println("Tree Empty");
        } else {
            node2 temp = root;
            node2 p = root;
            while (temp != null) {
                if ((strToAsc(temp.word.toLowerCase()) == strToAsc(word.toLowerCase())) && (temp.word.equalsIgnoreCase(word))) {
                    str = "word: " + temp.word + " meaining: " + temp.meaning;
                    found = true;
                    break;
                } else if ((strToAsc(word.toLowerCase()) >= strToAsc(temp.word.toLowerCase())) && (!word.equalsIgnoreCase(temp.word))) {
                    p = temp;
                    temp = temp.right;
                } else {
                    p = temp;
                    temp = temp.left;
                }
            }
            if (temp == null) {
                return "Not Found";
            }
        }
        return str;
    }

    public boolean delete(String word) {
        boolean found = false;
        if (root == null) {
            System.out.println("Tree Empty");
        } else {
            node2 temp = root;
            node2 p = root;
            while (temp != null) {
                if ((strToAsc(temp.word.toLowerCase()) == strToAsc(word.toLowerCase())) && (temp.word.equalsIgnoreCase(word))) {
                    found = true;
                    break;
                } else if ((strToAsc(word.toLowerCase()) >= strToAsc(temp.word.toLowerCase())) && (!word.equalsIgnoreCase(temp.word))) {
                    p = temp;
                    temp = temp.right;
                } else {
                    p = temp;
                    temp = temp.left;
                }
            }
            if (temp == null) {
                return found;
            } else if (temp.left == null && temp.right == null) {
                if (strToAsc(word) < strToAsc(temp.word)) {
                    p.left = null;
                } else {
                    p.right = null;
                }
            } //ONE CHILD
            else if ((temp.left != null && temp.right == null) || (temp.left == null && temp.right != null)) {
                if (temp.left != null && temp.right == null) {
                    if (strToAsc(word.toLowerCase()) < strToAsc(temp.word.toLowerCase())) {
                        p.left = temp.left;
                    } else {
                        p.right = temp.left;
                    }
                } else if (temp.left == null && temp.right != null) {
                    if (strToAsc(word.toLowerCase()) < strToAsc(temp.word.toLowerCase())) {
                        p.left = temp.right;
                    } else {
                        p.right = temp.right;
                    }
                }
            } 
            else {
                node2 var = temp.left;
                node2 p2 = temp.left;
                while (var != null) {
                    p2 = var;
                    var = var.right;
                }
                String word1 = p2.word;
                String mean = p2.meaning;
                delete(p2.word);
                temp.word = word1;
                temp.meaning = mean;
            }
        }
        return found;
    }

    public void display() {
        if (root == null) {
            return;
        }
        Stack<node2> stack = new Stack<node2>();
        node2 current = root;
        while (current != null || stack.size() > 0) {
            while (current != null) {
                stack.push(current);
                current = current.left;
            }
            current = stack.pop();
            System.out.print("word: " + current.word + " meaning: " + current.meaning + "\n");
            current = current.right;
        }
    }

}
