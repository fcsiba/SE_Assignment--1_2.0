/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp 22962
 */
public class DicHash {
        doublyLL[] Table;
        DicHash(int size) {
             Table = new doublyLL[size];
               for (int i = 0; i < Table.length; i++) {
                      Table[i] = new doublyLL();

        }
    }

    public int Hash(long index) {

        return (int) (index % Table.length);

    }

    public void insert(String obj, String meaning) {
        long sum = 0;
        for (int i = 0; i < obj.length(); i++) {
            sum += obj.charAt(i);

        }
        int index = Hash(sum);

        Table[index].insert("Word " + obj, "Meaning " + meaning);

    }

    public void find(String obj) {
        long sum = 0;
        for (int i = 0; i < obj.length(); i++) {
            sum += obj.charAt(i);
        }
        int index = Hash(sum);
        while (Table != null) {
            if (Table[index].equals(obj) || Table[index].Find(obj)!=null ) {
                System.out.println("Found Successfully..!!");
            } else {
                index = Hash(sum + 1);
            }

            System.out.println("Did not find any data ..!!");
        }
    }

    public void displayTable() {

        for (int i = 1; i < Table.length; i++) {
            System.out.println("ind= " + i + " " + Table[i].toString());
        }
    }

}
