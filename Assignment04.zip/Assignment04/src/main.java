/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//package javaapplication46;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 *
 * @author hp 22962
 */
public class main {
    public static void main(String[] args) {
        DicHash dh = new DicHash(400);
        String word = "";
        String mean = "";
        try {
            FileInputStream fstream = new FileInputStream("C:\\Users\\hp\\Documents\\NetBeansProjects\\Assignment04\\src\\Dictionary.csv");

            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String strLine = null;

            while ((strLine = br.readLine()) != null) {

                String arr[] = strLine.split("  ");
                word = arr[0];
                mean = arr[1];

                dh.insert(word, mean);
            }
            in.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
        dh.displayTable();
    }


}
