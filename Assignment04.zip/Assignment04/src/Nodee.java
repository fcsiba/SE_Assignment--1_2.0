/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp 22962
 */
public class Nodee {
    Nodee right ;
    Nodee left;
    int  data;
    Nodee(int data){
        this.data = data;
        this.right = null;
        this.left = null;
        
        
    }
    
    
}
