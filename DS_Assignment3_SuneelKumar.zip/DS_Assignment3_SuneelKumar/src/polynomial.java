/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hp
 */
public class polynomial{
    Node head;
public void insert(int c, int p){
    //code here 
    Node n = new Node(c,p);
    if(head== null){
        head =n;
       //head.power = p;
    }
    else{
        Node curr=head;
        while(curr.next!=null){
            curr = curr.next;
        }
        curr.next = n;
        //curr.next.power = p;
    }
}
public void addition( polynomial p1, polynomial p2){
  
Node curr1 =p1.head;
Node curr2 = p2.head;
polynomial sum =null;
Node curr3 = new Node(0,0);
if(p1!=null && p2==null){
    sum =p1;
  
}
else if(p1==null && p2!= null){
    sum = p2;
}
while(p1!=null && p2!=null){
    //curr3 =null;
    while(curr1.next!=null&& curr2.next!=null){
        curr3 = sum.head;
        if(curr1.power ==curr2.power){
            curr3.coefficient = curr1.coefficient+curr2.coefficient;
            curr3.power=curr1.power;
            
           sum.insert(curr3.coefficient, curr3.power);
            curr2 = curr2.next;
            curr1 = curr1.next;
        }
        else if(curr1.power > curr2.power){
            curr3.coefficient = curr2.coefficient;
            curr3.power= curr2.power;
            sum.insert(curr3.coefficient, curr3.power);
            curr2 = curr2.next;
        }
        else if(curr1.power < curr2.power){
            curr3.coefficient = curr1.coefficient;
            curr3.power = curr1.power;
            sum.insert(curr3.coefficient, curr3.power);
            curr1 = curr1.next;
        }
       
    }
   
}
//sum.insert(curr3.coefficient, curr3.power);

}
public void displayequation() { 
// code here 
Node  temp=head;
        String name= " ";
       if(temp==null)
        {
            System.out.println( "empty list");
        }
        else
        {
            while(temp!=null )
            {
              
              if(temp.power ==1)
              {
                  name+= temp.coefficient+"x"+"+";
              }
              else if(temp.power== 0){
                  name+= temp.coefficient;
              }
              else{
                name+=  temp.coefficient+"x^"+temp.power + "+";
              }
             temp=temp.next;
               
            }
        }
       System.out.println(name);
    
}


public static void main(String[] args){
    polynomial p1=new polynomial();
polynomial p2=new polynomial();
polynomial p4 = new polynomial();
p1.insert(3, 2);
p1.insert(4, 1);
p1.insert(10, 0);

p2.insert(3, 2);
p2.insert(3, 1);
p2.insert(2, 0);
//p2.insert(4, 1);

p1.displayequation();
p2.displayequation();

//p2.displayequation();
//System.out.println("after addition =");
//p4.addition(p1, p2);
//p4.displayequation();
}
}
