/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SearchEngine;

/**
 *
 * @author hp
 */
public class WordCollectionArrayBased {
    
WordList[] array;
 public WordCollectionArrayBased()
 {
     array=new  WordList[26];
     for(int i=0;i<array.length;i++)
     {
         array[i]=new WordList();
     }
 }
 public void Insert(String Word,URLList a)
 {
     
     int ascii=((int)(Word.toUpperCase().charAt(0)))-65;
     array[ascii].insert(Word,  a);
    
 }
 
 public void search(String title)
 {
     
      int ascii=((int)(title.toUpperCase().charAt(0)))-65;
        array[ascii].search(title); 
         System.out.println("index at which word is stored = " + ascii);
         System.out.println();
 }  
 public String toString()
 {
     String str=" ";
     for(int i=0;i<array.length;i++)
     {
         str+=array[i].toString();
     }
     return str;
 }
    
}
