/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SearchEngine;

/**
 *
 * @author hp
 */
public class WordList {
    Node1 head;
public void insert(String c , URLList l){ //code here 
    Node1 n = new Node1(c,l);
    if(head== null){
        head =n;
       //head.power = p;
    }
    else{
        Node1 curr=head;
        while(curr.next!=null){
            curr = curr.next;
        }
        curr.next = n;
        //curr.next.power = p;
    }
}
void delete (String tit )
    {
      Node1 temp=head;
      while(temp!=null)
      {
          if(temp.word.equals(tit))
          {
              break;
              
          }
          temp=temp.next;
      }
      if(temp==null)
      {
          System.out.println("Khaali");
      }
      if(temp!=null)
      {
          if(temp==head)
          {
             head=head.next;
             System.out.println("came1");
          }
          else if(temp.next==null)
          {
             
              temp.prev.next=null;
                 System.out.println("came2");
          }
            
          else
          {
                  System.out.println("came3");
              temp.prev.next=temp.next;
              temp.next.prev=temp.prev;
          }
      }
    }
  public String toString()
    {
        
        Node1  temp=head;
        String name= " ";
       

        if(temp==null)
        {
            return "empty list";
        }
        else
        {
            while(temp!=null )
            {
                
             
               
                name+=  temp.word + ", ";
                
                temp=temp.next;
               
            }
        }
       return name;
        
    }
  void search(String tit )
    {
        Node1 temp=head;
        while(temp!=null)
        {
         if(temp.word.equals(tit))
         {
             System.out.println(tit+" -> "+  temp.i);
         
         }
         
         temp=temp.next;
        }
        
        
        }
       
}


