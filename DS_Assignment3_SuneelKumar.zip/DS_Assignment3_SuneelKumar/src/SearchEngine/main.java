/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SearchEngine;

/**
 *
 * @author hp
 */
public class main {
    public static void main(String[] args){
        System.out.println("---------------------------------------------------");
        System.out.println("Nested LinkedList Based");
        System.out.println("---------------------------------------------------");
    URLList u = new URLList();
    u.insert("wiki.com");
    u.insert("iba.edu.pk");
    u.insert("ibm.com");
    URLList w = new URLList();
    w.insert("lums.com");
    w.insert("iba.com");
    w.insert("yahoo.com");
    URLList v = new URLList();
    v.insert("wikipedia.com");
    v.insert("nust.com");
    v.insert("yahoo.com");
    
    WordList x = new WordList();
    x.insert("Asia", u);
    x.insert("Karachi", w);
    x.insert("Admission", v);
    System.out.println("<<<Searching>>>");
    x.search("Karachi");
    x.search("Admission");
    x.search("Asia");
   
   System.out.println("-------------------------------------------------");
        System.out.println("Array Based ");
        System.out.println("-------------------------------------------------");
    WordCollectionArrayBased b = new WordCollectionArrayBased();
    b.Insert("Asia", u);
    b.Insert("Karachi" , w);
    b.Insert("Admission", v);
    b.Insert("Board",u );
    System.out.println("<<<Searching>>>");
    b.search("Asia");
    b.search("Karachi");
    b.search("Admission");
    b.search("Board");
    //System.out.println(b.toString());
    
    }
    
}
