/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SearchEngine;

/**
 *
 * @author hp
 */
public class URLList {
    Node2 head;
public void insert(String c){ //code here 
    Node2 n = new Node2(c);
    if(head== null){
        head =n;
       //head.power = p;
    }
    else{
        Node2 curr=head;
        while(curr.next!=null){
            curr = curr.next;
        }
        curr.next = n;
        //curr.next.power = p;
    }
}
  public String toString()
    {
        
        Node2  temp=head;
        String name= " ";
       

        if(temp==null)
        {
            return "empty list";
        }
        else
        {
            while(temp!=null )
            {
                
             
               
                name+=  temp.url + ", ";
                
                temp=temp.next;
               
            }
        }
       return name;
        
    }

}
