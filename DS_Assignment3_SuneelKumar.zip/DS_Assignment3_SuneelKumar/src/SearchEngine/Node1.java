/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SearchEngine;

/**
 *
 * @author hp
 */
public class Node1 {
    Node1 next;
    Node1 prev;
    String word;
    URLList i;
    Node1(String s, URLList l){
        this.word =s;
        this.i = l;
    }
    
}
